"""ssb-pseudonymization - Data pseudonymization functions used by SSB"""

__version__ = '0.0.2'
__author__ = 'Statistics Norway (ssb.no)'
__all__ = []
